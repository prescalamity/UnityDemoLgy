package com.unity3d.player;

public interface IUnityPlayerLifecycleEvents {

    public abstract void onUnityPlayerUnloaded();
    public abstract void onUnityPlayerQuitted();

}
