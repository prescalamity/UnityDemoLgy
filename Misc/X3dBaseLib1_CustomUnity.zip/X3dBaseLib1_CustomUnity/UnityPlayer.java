package com.unity3d.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import android.os.MessageQueue.IdleHandler;
import android.os.Process;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.InputEvent;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class UnityPlayer extends FrameLayout {
    public static Activity currentActivity = null;



    class AnonymousClass3 extends BroadcastReceiver {


        public void onReceive(Context context, Intent intent) {

        }
    }

    private abstract class f implements Runnable {
        final /* synthetic */ UnityPlayer e;

        private f(UnityPlayer unityPlayer) {
            this.e = unityPlayer;
        }

        public abstract void a();

        public final void run() {
            if (!this.e.isFinishing()) {
                a();
            }
        }
    }

    class a implements SensorEventListener {
        final /* synthetic */ UnityPlayer a;

        a(UnityPlayer unityPlayer) {
            this.a = unityPlayer;
        }

        public final void onAccuracyChanged(Sensor sensor, int i) {
        }

        public final void onSensorChanged(SensorEvent sensorEvent) {
        }
    }

    enum b {
        ;

        static {

        }
    }

    private class c extends PhoneStateListener {
        final /* synthetic */ UnityPlayer a;

        private c(UnityPlayer unityPlayer) {
            this.a = unityPlayer;
        }

        public final void onCallStateChanged(int i, String str) {
            boolean z = true;
            UnityPlayer unityPlayer = this.a;
            if (i != 1) {
                z = false;
            }
            unityPlayer.nativeMuteMasterAudio(z);
        }
    }

    enum d {
        PAUSE,
        RESUME,
        QUIT,
        SURFACE_LOST,
        SURFACE_ACQUIRED,
        FOCUS_LOST,
        FOCUS_GAINED,
        NEXT_FRAME
    }

    private class e extends Thread {
        Handler a;
        boolean b;
        boolean c;
        int d;
        int e;
        final /* synthetic */ UnityPlayer f;

        private e(UnityPlayer unityPlayer) {
            this.f = unityPlayer;
            this.b = false;
            this.c = false;
            this.e = 5;
        }

        private void a(d dVar) {
            Message.obtain(this.a, 2269, dVar).sendToTarget();
        }

        public final void a() {

        }

        public final void a(Runnable runnable) {

        }

        public final void b() {

        }

        public final void b(Runnable runnable) {


        }

        public final void c() {

        }

        public final void c(Runnable runnable) {

        }

        public final void d() {

        }

        public final void run() {

        }
    }

    static {

    }

    public UnityPlayer(Context context) {
        super(context);

    }

    public UnityPlayer(Context context, IUnityPlayerLifecycleEvents iUnityPlayerLifecycleEvents) {
        super(context);

    }

    public static void UnitySendMessage(String str, String str2, String str3) {

    }

    private void a() {

    }

    private void a(int i, Surface surface) {

    }

    private static void a(Activity activity) {

    }

    private static void a(ApplicationInfo applicationInfo) {

    }

    private void a(View view, View view2) {
        int i;

    }

    private void a(f fVar) {

    }

    private SurfaceView b() {

        return null;
    }

    private void b(Runnable runnable) {

    }

    private boolean b(final int i, final Surface surface) {


        return true;
    }

    private void c() {

    }

    private void d() {


    }

    private void e() {

    }

    private void f() {

    }

    private static void g() {

    }

    private ApplicationInfo h() {
        return null;
    }

    private boolean i() {

            return false;

    }

    private final native void initJni(Context context);

    private boolean j() {
        return false;
    }

    private void k() {

    }

    protected static boolean loadLibraryStatic(String str) {

            return false;

    }

    private final native void nativeDone();

    private final native void nativeFocusChanged(boolean z);

    private final native void nativeInitWebRequest(Class cls);

    private final native boolean nativeInjectEvent(InputEvent inputEvent);

    private final native boolean nativeIsAutorotationOn();

    private final native void nativeLowMemory();

    private final native void nativeMuteMasterAudio(boolean z);

    private final native boolean nativePause();

    private final native void nativeRecreateGfxState(int i, Surface surface);

    private final native boolean nativeRender();

    private final native void nativeRestartActivityIndicator();

    private final native void nativeResume();

    private final native void nativeSetInputString(String str);

    private final native void nativeSoftInputCanceled();

    private final native void nativeSoftInputClosed();

    private final native void nativeSoftInputLostFocus();

    private static native void nativeUnitySendMessage(String str, String str2, String str3);

    final void a(Runnable runnable) {

    }

    protected void addPhoneCallListener() {

    }

    public boolean addViewToPlayer(View view, boolean z) {
        boolean z2 = true;
        return z2;
    }

    public void configurationChanged(Configuration configuration) {

    }

    protected void disableLogger() {

    }

    public boolean displayChanged(int i, Surface surface) {
        return b(i, surface);
    }

    protected void executeGLThreadJobs() {

    }

    public Bundle getSettings() {
        return Bundle.EMPTY;
    }

    protected int getSplashMode() {

            return 0;

    }

    public View getView() {
        return this;
    }

    protected void hideSoftInput() {

    }

    public void init(int i, boolean z) {
    }

    protected boolean initializeGoogleAr() {

        return false;
    }

    protected boolean initializeGoogleVr() {

            return false;

    }

    public boolean injectEvent(InputEvent inputEvent) {
        return nativeInjectEvent(inputEvent);
    }

    protected boolean isFinishing() {

        return true;
    }

    protected void kill() {
        Process.killProcess(Process.myPid());
    }

    protected boolean loadLibrary(String str) {
        return loadLibraryStatic(str);
    }

    public void lowMemory() {

    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        return injectEvent(motionEvent);
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return injectEvent(keyEvent);
    }

    public boolean onKeyLongPress(int i, KeyEvent keyEvent) {
        return injectEvent(keyEvent);
    }

    public boolean onKeyMultiple(int i, int i2, KeyEvent keyEvent) {
        return injectEvent(keyEvent);
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        return injectEvent(keyEvent);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        return injectEvent(motionEvent);
    }

    public void pause() {

    }

    public void quit() {

    }

    public void removeViewFromPlayer(View view) {

    }

    public void reportError(String str, String str2) {

    }

    protected void reportSoftInputStr(final String str, final int i, final boolean z) {

    }

    public void resume() {

    }

    protected void setSoftInputStr(final String str) {

    }

    protected void showSoftInput(String str, int i, boolean z, boolean z2, boolean z3, boolean z4, String str2) {

    }

    protected boolean showVideoPlayer(String str, int i, int i2, int i3, boolean z, int i4, int i5) {

        return false;
    }

    public void start() {
    }

    public void stop() {
    }

    protected void toggleGyroscopeSensor(boolean z) {

    }

    public void windowFocusChanged(boolean z) {

    }

    public void  newIntent(Intent intent){

    }

    public void  destroy(){

    }
}